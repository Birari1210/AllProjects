package com.project.sma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShowRoomManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShowRoomManagmentApplication.class, args);
	}

}
